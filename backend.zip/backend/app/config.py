import os
from pydantic_settings import BaseSettings
from typing import List

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KB_DIR = os.path.join(BASE_DIR, "data", "knowledge_base")
CHROMA_DIR = os.path.join(BASE_DIR, "chroma_db")

class Settings(BaseSettings):
    CHROMA_PERSIST_DIR: str = CHROMA_DIR
    EMBEDDING_MODEL: str = "all-MiniLM-L6-v2"
    CHUNK_SIZE: int = 1000
    CHUNK_OVERLAP: int = 200
    TOP_K_RESULTS: int = 5
    LLM_PROVIDER: str = "local"
    CORS_ORIGINS: List[str] = ["*"]
    KNOWLEDGE_BASE_DIR: str = KB_DIR
    
    class Config:
        env_file = os.path.join(BASE_DIR, ".env")
        extra = "ignore"

settings = Settings()

