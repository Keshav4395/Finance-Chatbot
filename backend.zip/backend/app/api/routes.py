from fastapi import APIRouter, Depends, Request
from sse_starlette.sse import EventSourceResponse
from app.models import QueryRequest, QueryResponse, HealthResponse, EvalResult
from app.rag.pipeline import RAGPipeline
from app.evaluation.eval_runner import EvalRunner
import asyncio
import json

router = APIRouter()
pipeline = RAGPipeline()

@router.on_event("startup")
async def startup_event():
    pipeline.initialize()

@router.post("/query", response_model=QueryResponse)
async def query(request: QueryRequest):
    user_query = request.get_query()
    response = pipeline.query(user_query, request.conversation_id)
    return response

@router.post("/query/stream")
async def query_stream(request: Request, body: QueryRequest):
    async def event_generator():
        user_query = body.get_query()
        sources_dict = pipeline.retrieve_sources(user_query)
        sources = [
            {
                "document": s.get("document", "Unknown"),
                "section": s.get("section", ""),
                "content": s.get("content", ""),
                "relevance_score": s.get("relevance_score", 0.0)
            }
            for s in sources_dict
        ]
        
        # Send initial metadata chunk with sources
        confidence = max(
            (float(source.get("relevance_score", 0.0)) for source in sources),
            default=0.0,
        )
        yield json.dumps({"sources": sources, "confidence": min(1.0, max(0.0, confidence))})
        
        # Stream response tokens
        for chunk in pipeline.llm_chain.generate_stream(user_query, sources_dict, body.conversation_id):
            if await request.is_disconnected():
                break
            yield json.dumps({"answer": chunk})
            await asyncio.sleep(0.01)
            
        yield "[DONE]"
            
    return EventSourceResponse(event_generator())


@router.get("/health", response_model=HealthResponse)
async def health():
    return HealthResponse(status="healthy")

@router.get("/stats")
async def stats():
    return pipeline.vector_store.get_collection_stats()

@router.post("/evaluate", response_model=EvalResult)
async def evaluate():
    runner = EvalRunner(pipeline)
    return runner.run_evaluation()

@router.get("/sources")
async def list_sources():
    import os
    from app.config import settings
    files = []
    if os.path.exists(settings.KNOWLEDGE_BASE_DIR):
        files = os.listdir(settings.KNOWLEDGE_BASE_DIR)
    return {"sources": files}

@router.post("/feedback")
async def feedback(data: dict):
    # Log feedback
    return {"status": "success"}
