from langchain_community.embeddings import HuggingFaceEmbeddings
from app.config import settings

class EmbeddingsModel:
    def __init__(self):
        self.embeddings = HuggingFaceEmbeddings(model_name=settings.EMBEDDING_MODEL)
        
    def get_embeddings(self):
        return self.embeddings
