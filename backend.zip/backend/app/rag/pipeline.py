import time
import uuid
from typing import Dict, Any
from app.rag.document_loader import DocumentLoader
from app.rag.chunker import Chunker
from app.rag.vector_store import VectorStore
from app.rag.retriever import Retriever
from app.rag.llm_chain import LLMChain
from app.config import settings
from app.models import QueryResponse, Source
import logging

logger = logging.getLogger(__name__)

class RAGPipeline:
    def __init__(self):
        self.vector_store = VectorStore()
        self.retriever = Retriever(self.vector_store)
        self.llm_chain = LLMChain()
        self.is_initialized = False

    def initialize(self):
        if self.is_initialized:
            return
            
        logger.info("Initializing RAG Pipeline...")
        self.vector_store.initialize()
        
        if not self.vector_store.is_populated():
            logger.info("Vector store empty. Loading documents...")
            loader = DocumentLoader(settings.KNOWLEDGE_BASE_DIR)
            docs = loader.load()
            if docs:
                chunker = Chunker()
                chunks = chunker.split_documents(docs)
                self.vector_store.add_documents(chunks)
                logger.info(f"Loaded {len(chunks)} chunks into vector store.")
            else:
                logger.warning("No documents found to load.")
        else:
            logger.info("Vector store already populated.")
            
        self.is_initialized = True

    def retrieve_sources(self, question: str):
        expected_file = self.llm_chain.source_file(question)
        if not expected_file:
            return []
        # Keep the source panel aligned with the policy file used for each answer.
        return [
            source for source in self.retriever.retrieve(question)
            if source.get("document") == expected_file
        ]

    def query(self, question: str, conversation_id: str = None) -> QueryResponse:
        start_time = time.time()
        
        if not conversation_id:
            conversation_id = str(uuid.uuid4())
            
        sources_dict = self.retrieve_sources(question)
        sources = [Source(**s) for s in sources_dict]
        
        llm_response = self.llm_chain.generate_response(question, sources_dict, conversation_id)
        
        processing_time = time.time() - start_time
        
        return QueryResponse(
            answer=llm_response["answer"],
            sources=sources,
            conversation_id=llm_response["conversation_id"],
            confidence_score=llm_response.get("confidence_score", 0.0),
            processing_time=processing_time
        )
