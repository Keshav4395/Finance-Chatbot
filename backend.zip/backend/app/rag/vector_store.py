import os
from typing import List, Dict, Any
from langchain_community.vectorstores import Chroma
from langchain_core.documents import Document
from app.config import settings
from app.rag.embeddings import EmbeddingsModel

class VectorStore:
    def __init__(self):
        self.persist_directory = settings.CHROMA_PERSIST_DIR
        self.embeddings_model = EmbeddingsModel().get_embeddings()
        self.collection_name = "fintech_rag"
        self._vectorstore = None

    def initialize(self):
        self._vectorstore = Chroma(
            collection_name=self.collection_name,
            embedding_function=self.embeddings_model,
            persist_directory=self.persist_directory
        )

    def is_populated(self) -> bool:
        if self._vectorstore is None:
            self.initialize()
        return self._vectorstore._collection.count() > 0

    def add_documents(self, documents: List[Document]):
        if self._vectorstore is None:
            self.initialize()
        self._vectorstore.add_documents(documents)
        if hasattr(self._vectorstore, "persist"):
            self._vectorstore.persist()


    def similarity_search(self, query: str, k: int = 5) -> List[Document]:
        if self._vectorstore is None:
            self.initialize()
        # Using similarity_search_with_score to get distances
        docs_and_scores = self._vectorstore.similarity_search_with_relevance_scores(query, k=k)
        results = []
        for doc, score in docs_and_scores:
            doc.metadata['relevance_score'] = score
            results.append(doc)
        # Fallback if relevance scores not supported directly:
        if not results:
             raw_docs = self._vectorstore.similarity_search(query, k=k)
             for doc in raw_docs:
                 doc.metadata['relevance_score'] = 1.0 # placeholder
                 results.append(doc)
        return results

    def get_collection_stats(self) -> Dict[str, Any]:
        if self._vectorstore is None:
            self.initialize()
        count = self._vectorstore._collection.count()
        return {"document_count": count, "collection_name": self.collection_name}
