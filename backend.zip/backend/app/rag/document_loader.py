import os
import fitz  # PyMuPDF
from typing import List
from langchain_core.documents import Document

class DocumentLoader:
    def __init__(self, directory: str):
        self.directory = directory

    def load(self) -> List[Document]:
        documents = []
        if not os.path.exists(self.directory):
            print(f"Directory {self.directory} not found.")
            return documents
            
        for filename in os.listdir(self.directory):
            filepath = os.path.join(self.directory, filename)
            if filename.endswith(".txt"):
                with open(filepath, "r", encoding="utf-8") as f:
                    content = f.read()
                documents.append(Document(page_content=content, metadata={"source": filename, "filename": filename}))
            elif filename.endswith(".pdf"):
                content = self._extract_text_from_pdf(filepath)
                documents.append(Document(page_content=content, metadata={"source": filename, "filename": filename}))
        return documents

    def _extract_text_from_pdf(self, filepath: str) -> str:
        text = ""
        try:
            doc = fitz.open(filepath)
            for page in doc:
                text += page.get_text()
            doc.close()
        except Exception as e:
            print(f"Error reading PDF {filepath}: {e}")
        return text
