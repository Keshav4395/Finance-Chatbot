from typing import List, Dict, Any
from app.rag.vector_store import VectorStore
from app.config import settings
from app.models import Source

class Retriever:
    def __init__(self, vector_store: VectorStore):
        self.vector_store = vector_store

    def retrieve(self, query: str, k: int = settings.TOP_K_RESULTS) -> List[Dict[str, Any]]:
        docs = self.vector_store.similarity_search(query, k=k)
        sources = []
        for doc in docs:
            sources.append({
                "document": doc.metadata.get("source", "Unknown"),
                "section": doc.metadata.get("section", ""),
                "content": doc.page_content,
                "relevance_score": doc.metadata.get("relevance_score", 0.0)
            })
        return sources
