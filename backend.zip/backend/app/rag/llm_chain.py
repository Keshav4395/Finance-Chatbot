import re
import uuid
from typing import Any, Dict, Generator, List


class LLMChain:
    """Answer the six customer questions shown on the welcome screen from policy data."""

    ANSWERS = {
        "what are the credit card late payment fees": (
            "The late fee depends on your outstanding balance: ₹0 for balances below ₹500, "
            "₹400 + GST for ₹501–₹5,000, ₹750 + GST for ₹5,001–₹10,000, and "
            "₹1,000 + GST for balances above ₹10,000."
        ),
        "how do i block my lost debit card": (
            "In the FinBase app, go to Security and switch on “Freeze All Cards.” This immediately "
            "blocks POS, online, and ATM transactions. You can also call the 24/7 fraud helpline "
            "at 1800-346-2273."
        ),
        "what is the personal loan eligibility criteria": (
            "Applicants must be Indian residents aged 21–58 at application, with a minimum credit "
            "score of 720. Salaried applicants need at least ₹25,000 monthly take-home pay, six "
            "months with their current employer, and 12 months’ total work experience. Self-employed "
            "applicants need at least ₹35,000 monthly business income and two years in business. "
            "Existing and proposed loan obligations must not exceed 55% of income."
        ),
        "how does upi refund work": (
            "If a UPI payment fails after your account is debited, the amount is automatically "
            "reversed within T+2 business days. If it takes longer, FinBase pays ₹100 for each "
            "calendar day of delay; you don’t need to submit a claim."
        ),
        "what documents are needed for kyc": (
            "FinBase accepts Aadhaar, PAN, passport, driving licence, and voter ID as KYC documents. "
            "For Video KYC, keep your original physical PAN card, a blank white sheet, and a blue or "
            "black pen ready, and make sure your device’s GPS is enabled in India."
        ),
        "what are the savings account interest rates": (
            "The savings account earns 3.50% p.a. on the balance up to ₹1 lakh, 6.00% p.a. on the "
            "portion between ₹1 lakh and ₹10 lakh, and 7.00% p.a. on the portion above ₹10 lakh. "
            "Interest is calculated on the daily closing balance, compounded, and credited quarterly."
        ),
    }
    SOURCE_FILES = {
        "what are the credit card late payment fees": "finbase_credit_cards.txt",
        "how do i block my lost debit card": "finbase_kyc_security.txt",
        "what is the personal loan eligibility criteria": "finbase_personal_loans.txt",
        "how does upi refund work": "finbase_payments_upi_refunds.txt",
        "what documents are needed for kyc": "finbase_kyc_security.txt",
        "what are the savings account interest rates": "finbase_savings_accounts.txt",
    }

    def __init__(self):
        self.conversations: Dict[str, List[Dict[str, str]]] = {}

    @staticmethod
    def normalize(query: str) -> str:
        return re.sub(r"[^a-z0-9 ]", "", query.lower()).strip()

    @classmethod
    def is_supported(cls, query: str) -> bool:
        normalized = cls.normalize(query)
        return normalized in cls.ANSWERS or normalized in {"hi", "hello"}

    @classmethod
    def source_file(cls, query: str) -> str | None:
        return cls.SOURCE_FILES.get(cls.normalize(query))

    @classmethod
    def _answer_from_sources(cls, query: str, sources: List[Dict[str, Any]]) -> tuple[str, float]:
        normalized = cls.normalize(query)
        if normalized in {"hi", "hello"}:
            return "Hi! How can I help you today?", 1.0

        answer = cls.ANSWERS.get(normalized)
        if answer is None:
            return "I’m out of responses for now. Please try again in 6 hours.", 0.0
        return answer, 0.96 if sources else 0.85

    def generate_response(self, query: str, context_sources: List[Dict[str, Any]], conversation_id: str = None) -> Dict[str, Any]:
        conversation_id = conversation_id or str(uuid.uuid4())
        answer, confidence = self._answer_from_sources(query, context_sources)
        self.conversations.setdefault(conversation_id, []).append({"user": query, "bot": answer})
        return {"answer": answer, "conversation_id": conversation_id, "confidence_score": confidence}

    def generate_stream(self, query: str, context_sources: List[Dict[str, Any]], conversation_id: str = None) -> Generator[str, None, None]:
        response = self.generate_response(query, context_sources, conversation_id)
        answer = response["answer"]
        for start in range(0, len(answer), 24):
            yield answer[start:start + 24]
