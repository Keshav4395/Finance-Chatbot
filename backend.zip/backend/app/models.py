from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any

class QueryRequest(BaseModel):
    query: Optional[str] = None
    question: Optional[str] = None
    conversation_id: Optional[str] = None

    def get_query(self) -> str:
        return self.query or self.question or ""


class Source(BaseModel):
    document: str
    section: str = ""
    content: str
    relevance_score: float

class QueryResponse(BaseModel):
    answer: str
    sources: List[Source]
    conversation_id: str
    confidence_score: float
    processing_time: float

class HealthResponse(BaseModel):
    status: str
    version: str = "1.0.0"

class EvalResult(BaseModel):
    total_questions: int
    avg_relevance: float
    avg_groundedness: float
    avg_citation_accuracy: float
    details: List[Dict[str, Any]]
