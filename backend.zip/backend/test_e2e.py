import sys
import os
sys.path.append(os.path.abspath("backend"))

from app.rag.pipeline import RAGPipeline

def main():
    print("--- 1. Initializing RAG Pipeline & Ingesting Documents ---")
    p = RAGPipeline()
    p.initialize()
    stats = p.vector_store.get_collection_stats()
    print("Vector Store Stats:", stats)

    print("\n--- 2. Testing Retrieval ---")
    test_q = "What is the transaction limit on a Minimum KYC account?"
    print(f"Query: {test_q}")
    docs = p.retriever.retrieve(test_q, k=2)
    for i, d in enumerate(docs):
        print(f"\n[Source {i+1}]: {d.get('document')}")
        print(f"Content excerpt: {d.get('content')[:250]}...")

    print("\n--- 3. Testing LLM Grounded Answer Generation ---")
    resp = p.query(test_q)
    print("\n--- Assistant Answer ---")
    print(resp.answer)
    print("\nProcessing time (s):", resp.processing_time)
    print("Sources cited:", len(resp.sources))

if __name__ == "__main__":
    main()
