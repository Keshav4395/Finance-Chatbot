import pytest
from backend.app.rag.document_loader import DocumentLoader

def test_document_loader_initialization():
    loader = DocumentLoader("./dummy_dir")
    assert loader.directory == "./dummy_dir"
